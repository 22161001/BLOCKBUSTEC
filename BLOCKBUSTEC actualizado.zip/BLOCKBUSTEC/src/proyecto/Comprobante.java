package proyecto;

import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

import java.io.FileOutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;

public class Comprobante {

    
    public static void generarPDF(String titulo, int dias, String precio, LocalDate fecha) {
        try {
            Document document = new Document();  
            String ruta = "ticket_renta.pdf";   
            PdfWriter.getInstance(document, new FileOutputStream(ruta));
            document.open();

            // Fuente para el título del PDF
            Font titleFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 18);
            Paragraph title = new Paragraph("Ticket de Renta", titleFont);
            title.setAlignment(Element.ALIGN_CENTER);
            document.add(title);

            // Agregar los datos de la renta al documento
            document.add(new Paragraph("Título: " + titulo));
            document.add(new Paragraph("Días de renta: " + dias));
            document.add(new Paragraph("Precio total: $" + precio));
            document.add(new Paragraph("Fecha: " + fecha.toString()));

            document.close();

            System.out.println("PDF generado correctamente.");
        } catch (Exception e) {
            System.err.println("Error al generar PDF:");
            e.printStackTrace();
        }
    }

    public static String obtenerCorreoUsuario(int idUsuario) {
        String correo = "";
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
         
            conn = DriverManager.getConnection(
                    "jdbc:postgresql://localhost:5433/blockbustec", "postgres", "conant14");

            String sql = "SELECT email FROM usuarios WHERE id_usuario = ?";
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, idUsuario);
            rs = stmt.executeQuery();

            if (rs.next()) {
                correo = rs.getString("email");
            }
        } catch (Exception e) {
            System.err.println("Error al obtener correo:");
            e.printStackTrace();
        } finally {
        
            try { if (rs != null) rs.close(); } catch (Exception e) { e.printStackTrace(); }
            try { if (stmt != null) stmt.close(); } catch (Exception e) { e.printStackTrace(); }
            try { if (conn != null) conn.close(); } catch (Exception e) { e.printStackTrace(); }
        }

        return correo;
    }

    public static void enviarComprobante(String titulo, int dias, String precio, LocalDate fecha, int idUsuario) {
        generarPDF(titulo, dias, precio, fecha);

        String correo = obtenerCorreoUsuario(idUsuario);
        if (!correo.isEmpty()) {
     
            Correo.enviarCorreoConPDF(correo, "ticket_renta.pdf");
        } else {
            System.out.println("No se encontró correo para el usuario con id: " + idUsuario);
        }
    }
}
