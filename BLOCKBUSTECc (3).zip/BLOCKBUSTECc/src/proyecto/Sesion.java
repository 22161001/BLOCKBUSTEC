package proyecto;



public class Sesion {
    public static String nombreUsuarioActivo;
    public static int idUsuarioActivo;
     public static int rolUsuarioActivo;
    
    public static int getIdUsuarioActivo() {
        return idUsuarioActivo;
    }
}
