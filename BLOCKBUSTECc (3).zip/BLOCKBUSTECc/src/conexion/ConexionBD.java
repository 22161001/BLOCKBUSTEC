package conexion;


import java.util.List;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.swing.JOptionPane;

import proyecto.Rol; 
public class ConexionBD {
    private static final String URL = "jdbc:postgresql://localhost:5432/bl"; 
    private static final String USUARIO = "postgres";
    private static final String CONTRASENA = "chowis"; // Contraseña actualizada

    public static Connection conectar() {
        Connection conexion = null;
        try {
            Class.forName("org.postgresql.Driver");
            conexion = DriverManager.getConnection(URL, USUARIO, CONTRASENA);
            System.out.println("Conexión exitosa a la base de datos");
        } catch (ClassNotFoundException | SQLException e) {
            System.err.println("Error al conectar a la base de datos: " + e.getMessage());
            
        }
        return conexion;
    }

}

