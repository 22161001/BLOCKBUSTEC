/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto;
public class Rol {
    private int idRol;
    private String nombreRol;

    public Rol(int idRol, String nombreRol) {
        this.idRol = idRol;
        this.nombreRol = nombreRol;
    }
public Rol() {
        
    }
    

    // Getters
    public int getIdRol() {
        return idRol;
    }

    public String getNombreRol() {
        return nombreRol;
    }
     public void setIdRol(int idRol) {
        this.idRol = idRol;
    }

    public void setNombreRol(String nombreRol) {
        this.nombreRol = nombreRol;
    }

    // ¡CRUCIAL! Este método es usado por JComboBox para mostrar el texto
    @Override
    public String toString() {
        return nombreRol;
    }
}
