
package proyecto;


import barrabusquedaPopup.barraBusqueda;

import conexion.ConexionBD;
import java.awt.Component;
import java.sql.Connection;  
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.Image;
import java.awt.image.BufferedImage;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author conan
 */
public class CatalogoPeliculas extends javax.swing.JFrame {

    private String nombreUsuario;

    /**
     * Creates new form CatalogoPeliculas
     */
    public CatalogoPeliculas() {
    initComponents();
    cargarDatosTabla();
    configurarBarraBusqueda();
}

private void configurarBarraBusqueda() {
    barraBusqueda1.addBusquedaListener(new barraBusqueda.BusquedaListener() {
        public void onBusquedaRealizada(String textoSeleccionado) {
            cargarPeliculaPorTitulo(textoSeleccionado);
        }
    });

    barraBusqueda1.cargarDesdeBaseDeDatos(
        "jdbc:postgresql://localhost:5433/blockbustec",
        "postgres",
        "conant14",
        "peliculas",
        "titulo"
    );
JTextField campo = barraBusqueda1.getCampoBusqueda(); // Usa correctamente el JTextField interno

        campo.getDocument().addDocumentListener(new DocumentListener() {
            private void verificarCampoVacio() {
                String texto = campo.getText().trim();
                if (texto.isEmpty()) {
                    cargarDatosTabla(); 
                }
            }

            @Override
            public void insertUpdate(DocumentEvent e) {
                verificarCampoVacio();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                verificarCampoVacio();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                verificarCampoVacio();
            }
        });
    }



    public static class ImageRenderer extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value,
                                                       boolean isSelected, boolean hasFocus, int row, int column) {
            if (value instanceof ImageIcon) {
                JLabel label = new JLabel();
                label.setIcon((ImageIcon) value);
                label.setHorizontalAlignment(JLabel.CENTER);
                return label;
            }
            return super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
        }
    }

    private void cargarDatosTabla() {
    String[] columnas = {"Imagen", "Título", "Año", "Duración", "Descripción", "Género", "Director", "ImagenURL", "Disponible"};
    DefaultTableModel model = new DefaultTableModel(null, columnas) {
        @Override
        public Class<?> getColumnClass(int columnIndex) {
            if (columnIndex == 0) return ImageIcon.class;
            if (columnIndex == 2 || columnIndex == 8) return Integer.class;
            return String.class;
        }

        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };

    try (Connection conn = ConexionBD.conectar()) {
      String sql = """
    SELECT p.id_pelicula,
           p.titulo,
           p.descripcion,
           g.nombre_genero AS genero, -- Asegúrate de que esta línea esté presente
           p.director,
           p.anio,
           p.duracion,
           p.imagen_url,
           p.stock
    FROM peliculas p
    JOIN genero g ON p.id_genero = g.id_genero
    ORDER BY p.titulo
""";
        PreparedStatement ps = conn.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();

        while (rs.next()) {
            int idpelicula=rs.getInt("id_pelicula");
            String titulo =  rs.getString("titulo");
            String descripcionUrl = rs.getString("descripcion");
              String genero = rs.getString("genero");
              String director = rs.getString("director");
            int anio = rs.getInt("anio");
            String duracion = rs.getString("duracion");
            
          
            
            String imagenUrl = rs.getString("imagen_url");
            int disponible = rs.getInt("stock");
               
               
               
               
               
                
                
               
                
            ImageIcon icon;
            try {
                Image img = new ImageIcon(imagenUrl).getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
                icon = new ImageIcon(img);
            } catch (Exception e) {
                icon = new ImageIcon(new BufferedImage(100, 100, BufferedImage.TYPE_INT_ARGB));
            }

            Object[] fila = {icon, titulo, anio, duracion, descripcionUrl, genero, director, imagenUrl, disponible};
            model.addRow(fila);
        }

        jTable1.setModel(model);
        jTable1.setRowHeight(100);
        jTable1.getColumnModel().getColumn(0).setCellRenderer(new ImageRenderer());

   
        for (int i = 4; i <= 8; i++) {
            jTable1.getColumnModel().getColumn(i).setMinWidth(0);
            jTable1.getColumnModel().getColumn(i).setMaxWidth(0);
            jTable1.getColumnModel().getColumn(i).setWidth(0);
        }

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error al cargar datos: " + e.getMessage());
    }
}

public void cargarPeliculaPorTitulo(String tituloBuscado) {
    String[] columnas = {"Imagen", "Título", "Año", "Duración", "Descripción", "Género", "Director", "ImagenURL", "Disponible"};
    DefaultTableModel model = new DefaultTableModel(null, columnas) {
        @Override
        public Class<?> getColumnClass(int columnIndex) {
            if (columnIndex == 0) return ImageIcon.class;
            if (columnIndex == 2 || columnIndex == 8) return Integer.class;
            return String.class;
        }

        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };

    try (Connection conn = ConexionBD.conectar()) {
        String sql = """
    SELECT p.id_pelicula,
           p.titulo,
           p.descripcion,
           g.nombre_genero AS genero,
           p.director,
           p.anio,
           p.duracion,
           p.imagen_url,
           p.stock
    FROM peliculas p
    JOIN genero g ON p.id_genero = g.id_genero
    WHERE p.titulo ILIKE ? -- ¡Esta es la adición!
    ORDER BY p.titulo
""";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, "%" + tituloBuscado + "%"); // Búsqueda flexible
        ResultSet rs = ps.executeQuery();

        while (rs.next()) {
           int idpelicula=rs.getInt("id_pelicula");
            String titulo =  rs.getString("titulo");
            String descripcionUrl = rs.getString("descripcion");
              String genero = rs.getString("genero");
              String director = rs.getString("director");
            int anio = rs.getInt("anio");
            String duracion = rs.getString("duracion");
            
          
            
            String imagenUrl = rs.getString("imagen_url");
            int disponible = rs.getInt("stock");
               

            ImageIcon icon;
            try {
                Image img = new ImageIcon(imagenUrl).getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
                icon = new ImageIcon(img);
            } catch (Exception e) {
                icon = new ImageIcon(new BufferedImage(100, 100, BufferedImage.TYPE_INT_ARGB));
            }

            Object[] fila = {icon, titulo, anio, duracion, descripcionUrl, genero, director, imagenUrl, disponible};
            model.addRow(fila);
        }

        jTable1.setModel(model);
        jTable1.setRowHeight(100);
        jTable1.getColumnModel().getColumn(0).setCellRenderer(new ImageRenderer());

        // Ocultar columnas
        for (int i = 4; i <= 8; i++) {
            jTable1.getColumnModel().getColumn(i).setMinWidth(0);
            jTable1.getColumnModel().getColumn(i).setMaxWidth(0);
            jTable1.getColumnModel().getColumn(i).setWidth(0);
        }

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error al buscar película: " + e.getMessage());
    }
    if (jTable1.getRowCount() > 0) {
    jTable1.setRowSelectionInterval(0, 0);
    jTable1.scrollRectToVisible(jTable1.getCellRect(0, 0, true));
}

}



        
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        btnVolver = new javax.swing.JButton();
        btnDetalles = new javax.swing.JButton();
        barraBusqueda1 = new barrabusquedaPopup.barraBusqueda();
        jPanel2 = new javax.swing.JPanel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        menuInicio = new javax.swing.JMenuItem();
        jSeparator1 = new javax.swing.JPopupMenu.Separator();
        menuCerrar = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Pelicula1", "Pelicula2", "Pelicula3", "Pelicula4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 110, 870, 350));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Showcard Gothic", 0, 26)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("CATALOGO DE PELICULAS");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 20, -1, -1));

        btnVolver.setText("Volver");
        btnVolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVolverActionPerformed(evt);
            }
        });
        jPanel1.add(btnVolver, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 490, -1, -1));

        btnDetalles.setText("Ver detalles");
        btnDetalles.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDetallesActionPerformed(evt);
            }
        });
        jPanel1.add(btnDetalles, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 490, -1, -1));
        jPanel1.add(barraBusqueda1, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 60, -1, -1));

        jPanel2.setBackground(new java.awt.Color(255, 102, 102));
        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 920, 540));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 920, 540));

        jMenu1.setText("=");

        menuInicio.setText("Inicio");
        menuInicio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuInicioActionPerformed(evt);
            }
        });
        jMenu1.add(menuInicio);
        jMenu1.add(jSeparator1);

        menuCerrar.setText("Cerrar Sesión");
        menuCerrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuCerrarActionPerformed(evt);
            }
        });
        jMenu1.add(menuCerrar);

        jMenuBar1.add(jMenu1);

        setJMenuBar(jMenuBar1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void menuInicioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuInicioActionPerformed
       
        // TODO add your handling code here:
       MenuPrincipal menu = new MenuPrincipal();
    menu.setVisible(true);
    this.dispose();
    }//GEN-LAST:event_menuInicioActionPerformed

    private void menuCerrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuCerrarActionPerformed
        // TODO add your handling code here:
        Login login = new Login();
    login.setVisible(true);
    this.dispose();
    }//GEN-LAST:event_menuCerrarActionPerformed

    private void btnDetallesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDetallesActionPerformed
        int fila = jTable1.getSelectedRow();
    if (fila == -1) {
        JOptionPane.showMessageDialog(this, "Selecciona una película.");
        return;
    }

    String titulo = (String) jTable1.getValueAt(fila, 1);
    int anio = (int) jTable1.getValueAt(fila, 2);
    String duracion = (String) jTable1.getValueAt(fila, 3);
    String descripcion = (String) jTable1.getValueAt(fila, 4);
    String genero = (String) jTable1.getValueAt(fila, 5);
    String director = (String) jTable1.getValueAt(fila, 6);
    String imagenUrl = (String) jTable1.getValueAt(fila, 7);
    int disponible = (int) jTable1.getValueAt(fila, 8);

    DetallePelicula detalle = new DetallePelicula(titulo, anio, duracion, descripcion, genero, director, imagenUrl, disponible);
    detalle.setVisible(true);
    this.dispose();
    }//GEN-LAST:event_btnDetallesActionPerformed

    private void btnVolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVolverActionPerformed
        // TODO add your handling code here:
       MenuPrincipal menu = new MenuPrincipal();
        menu.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnVolverActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CatalogoPeliculas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CatalogoPeliculas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CatalogoPeliculas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CatalogoPeliculas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CatalogoPeliculas().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private barrabusquedaPopup.barraBusqueda barraBusqueda1;
    private javax.swing.JButton btnDetalles;
    private javax.swing.JButton btnVolver;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPopupMenu.Separator jSeparator1;
    private javax.swing.JTable jTable1;
    private javax.swing.JMenuItem menuCerrar;
    private javax.swing.JMenuItem menuInicio;
    // End of variables declaration//GEN-END:variables
}
