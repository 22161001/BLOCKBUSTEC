package proyecto;

import conexion.ConexionBD;
import java.sql.*;
import java.time.LocalDate;
import javax.swing.*;

public class RentarPeliculas extends javax.swing.JFrame {
    
    private String tituloPelicula;

     
   
   public RentarPeliculas(String tituloPelicula) {
    initComponents();
    configurarSpinner();
    this.tituloPelicula = tituloPelicula;
}
public RentarPeliculas() {
    initComponents();
    configurarSpinner();
}

    private void configurarSpinner() {
         spDias.setModel(new SpinnerNumberModel(1, 1, 5, 1));
        int precioPorDia = 10;

        spDias.addChangeListener(e -> {
            int dias = (int) spDias.getValue();
            if (dias < 1) {
                dias = 1;
                spDias.setValue(1);
            }
            int total = dias * precioPorDia;
            lblPrecio.setText("$" + total + ".00");
        });

        int diasInicial = (int) spDias.getValue();
        lblPrecio.setText("$" + (diasInicial * precioPorDia) + ".00");
    }

    private int obtenerIdPeliculaPorTitulo(String titulo) {
    int idPelicula = -1;
    try (Connection conn = ConexionBD.conectar()) {
        String sql = "SELECT id_pelicula FROM peliculas WHERE titulo = ?";
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setString(1, titulo);
        ResultSet rs = stmt.executeQuery();
        if (rs.next()) {
            idPelicula = rs.getInt("id_pelicula");
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error al obtener ID de la película: " + e.getMessage());
    }
    return idPelicula;
}

    private int obtenerDisponibilidad(int idPelicula) {
        int disponibles = 0;
        try (Connection conn = ConexionBD.conectar()) {
            String sql = "SELECT stock FROM peliculas WHERE id_pelicula = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, idPelicula);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                disponibles = rs.getInt("stock");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al consultar disponibilidad: " + e.getMessage());
        }
        return disponibles;
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        btnConfirmar = new javax.swing.JButton();
        btnCancelar = new javax.swing.JButton();
        lblPrecio = new javax.swing.JLabel();
        spDias = new javax.swing.JSpinner();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        menuInicio = new javax.swing.JMenuItem();
        jSeparator1 = new javax.swing.JPopupMenu.Separator();
        menuCerrar = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Showcard Gothic", 0, 26)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("RENTAR PELICULAS");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(98, 6, -1, 45));

        jPanel1.setBackground(new java.awt.Color(255, 102, 102));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnConfirmar.setText("Confirmar");
        btnConfirmar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConfirmarActionPerformed(evt);
            }
        });
        jPanel1.add(btnConfirmar, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 280, -1, -1));

        btnCancelar.setText("Cancelar");
        btnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarActionPerformed(evt);
            }
        });
        jPanel1.add(btnCancelar, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 280, -1, -1));

        lblPrecio.setBackground(new java.awt.Color(255, 204, 204));
        lblPrecio.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(lblPrecio, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 170, 107, 20));
        jPanel1.add(spDias, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 92, 130, 30));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel3.setText("Dias de renta:");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(83, 96, -1, -1));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel4.setText("Precio:");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(127, 167, -1, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 370, 350));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 0, 100, 350));

        jMenu1.setText("=");

        menuInicio.setText("Inicio");
        menuInicio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuInicioActionPerformed(evt);
            }
        });
        jMenu1.add(menuInicio);
        jMenu1.add(jSeparator1);

        menuCerrar.setText("Cerrar Sesion");
        menuCerrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuCerrarActionPerformed(evt);
            }
        });
        jMenu1.add(menuCerrar);

        jMenuBar1.add(jMenu1);

        setJMenuBar(jMenuBar1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void menuInicioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuInicioActionPerformed
        // TODO add your handling code here:
        MenuPrincipal menu = new MenuPrincipal();
    menu.setVisible(true);
    this.dispose();
    }//GEN-LAST:event_menuInicioActionPerformed

    private void btnConfirmarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConfirmarActionPerformed

    String titulo = this.tituloPelicula;
        int dias = (int) spDias.getValue();
        String precioTexto = lblPrecio.getText().replace("$", "").replace(".00", "");
        double precioRenta = Double.parseDouble(precioTexto);
        LocalDate fechaRenta = LocalDate.now();
        LocalDate fechaDevolucion = fechaRenta.plusDays(dias);

        int idUsuario = Sesion.getIdUsuarioActivo();
        int idPelicula = obtenerIdPeliculaPorTitulo(titulo);

        if (idPelicula == -1) {
            JOptionPane.showMessageDialog(this, "No se pudo encontrar la película en la base de datos.");
            return;
        }

        int disponibles = obtenerDisponibilidad(idPelicula);
        if (disponibles <= 0) {
            JOptionPane.showMessageDialog(this, "No hay ejemplares disponibles de esta película.");
            return;
        }

        try (Connection conn = ConexionBD.conectar()) {
            conn.setAutoCommit(false);

            String sqlInsert = "INSERT INTO rentas (id_usuario, id_pelicula, fecha_renta, fecha_devolucion, estado, precio_renta, estado_pago) " +
                               "VALUES (?, ?, ?, ?, ?, ?, ?) RETURNING id_renta";
            PreparedStatement stmtInsert = conn.prepareStatement(sqlInsert);
            stmtInsert.setInt(1, idUsuario);
            stmtInsert.setInt(2, idPelicula);
            stmtInsert.setDate(3, Date.valueOf(fechaRenta));
            stmtInsert.setDate(4, Date.valueOf(fechaDevolucion));
            stmtInsert.setString(5, "En renta");
            stmtInsert.setDouble(6, precioRenta);
            stmtInsert.setString(7, "Pendiente");

            ResultSet rs = stmtInsert.executeQuery();
            int idRenta = -1;
            if (rs.next()) {
                idRenta = rs.getInt("id_renta");
            }

            String sqlUpdate = "UPDATE peliculas SET stock = stock - 1 WHERE id_pelicula = ?";
            PreparedStatement stmtUpdate = conn.prepareStatement(sqlUpdate);
            stmtUpdate.setInt(1, idPelicula);
            stmtUpdate.executeUpdate();

            conn.commit();

            JOptionPane.showMessageDialog(this, "Renta confirmada.");

            HistorialRentas historial = new HistorialRentas(this);
            historial.setVisible(true);
            this.setVisible(false);
            this.dispose();

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al registrar la renta: " + e.getMessage());
        }

    }//GEN-LAST:event_btnConfirmarActionPerformed

    private void btnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarActionPerformed
        // TODO add your handling code here:
      DetallePelicula detalle = new DetallePelicula();
    detalle.setVisible(true);
    this.dispose();
    }//GEN-LAST:event_btnCancelarActionPerformed

    private void menuCerrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuCerrarActionPerformed
        // TODO add your handling code here:
        Login login = new Login();
    login.setVisible(true);
    this.dispose();
    }//GEN-LAST:event_menuCerrarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(RentarPeliculas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(RentarPeliculas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(RentarPeliculas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(RentarPeliculas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new RentarPeliculas().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCancelar;
    private javax.swing.JButton btnConfirmar;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPopupMenu.Separator jSeparator1;
    private javax.swing.JLabel lblPrecio;
    private javax.swing.JMenuItem menuCerrar;
    private javax.swing.JMenuItem menuInicio;
    private javax.swing.JSpinner spDias;
    // End of variables declaration//GEN-END:variables
}
