
package proyecto;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfWriter;
import conexion.ConexionBD;
import java.io.FileOutputStream;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import jakarta.mail.*;
import jakarta.mail.internet.*;
import java.util.Properties;
import java.io.File;

import java.time.LocalDate;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;

/**
 *
 * @author conan
 */
public class Ticket extends javax.swing.JFrame {
     private int idrenta;
    private String nombreUsuario;
private String nombrePelicula;
private LocalDate fechaRenta;
private LocalDate fechaDevolucion;
private String precioRenta;

public Ticket(int idrenta,  String nombreUsuario, String nombrePelicula, LocalDate fechaRenta, LocalDate fechaDevolucion, String precioRenta, String  emailUsuario) {
   this.idrenta=idrenta;
    this.nombreUsuario = nombreUsuario;
    this.nombrePelicula = nombrePelicula;
    this.fechaRenta = fechaRenta;
    this.fechaDevolucion = fechaDevolucion;
    this.precioRenta = precioRenta;
    initComponents();
    mostrarInfo();
}


public Ticket() {
    initComponents();
}


   private void mostrarInfo() {
    String info = "<html><body style='width: 300px;'>"
        + "<h3>🎬 BLOCKBUSTEC</h3>"
        + "<p><b>Usuario:</b> " + nombreUsuario + "</p>"
        + "<p><b>Película:</b> " + nombrePelicula + "</p>"
        + "<p><b>Fecha de renta:</b> " + fechaRenta.toString() + "</p>"
        + "<p><b>Fecha de devolución:</b> " + fechaDevolucion.toString() + "</p>"
        + "<p><b>Precio renta:</b> " + precioRenta + "</p>"
        + "<p>❤️ ¡Gracias por su preferencia! ❤️</p>"
        + "</body></html>";
    lblInfo.setText(info);
}

    


    private double parsePrecio(String precioStr) {
        // Elimina símbolos $ y comas para convertir a double
        try {
            return Double.parseDouble(precioStr.replace("$", "").replace(",", "").trim());
        } catch (Exception e) {
            return 0.0;
        }
    }

    public static String generarPDFTicket(String nombreUsuario, String nombrePelicula, LocalDate fechaRenta, LocalDate fechaDevolucion, String precioRenta) {
    String filePath = "ticket_renta.pdf";
    try {
        Document document = new Document();
        PdfWriter.getInstance(document, new FileOutputStream(filePath));
        document.open();

        Font titleFont = new Font(Font.FontFamily.HELVETICA, 18, Font.BOLD);
        Font bodyFont = new Font(Font.FontFamily.HELVETICA, 12);

        document.add(new Paragraph("🎬 BlockbusTec - Ticket de Renta", titleFont));
        document.add(new Paragraph(" ")); // espacio

        document.add(new Paragraph("Usuario: " + nombreUsuario, bodyFont));
        document.add(new Paragraph("Película: " + nombrePelicula, bodyFont));
        document.add(new Paragraph("Fecha de renta: " + fechaRenta.toString(), bodyFont));
        document.add(new Paragraph("Fecha de devolución: " + fechaDevolucion.toString(), bodyFont));
        document.add(new Paragraph("Precio renta: " + precioRenta, bodyFont));

        document.add(new Paragraph("Gracias por su preferencia ❤️", bodyFont));

        document.close();
        return filePath;

    } catch (Exception e) {
        e.printStackTrace();
        return null;
    }
}


    public static String obtenerCorreoPorIdUsuario(int idrenta) {
    String correo = "";
  String sql = """
    SELECT u.email
    FROM usuarios u
    JOIN rentas r ON u.id_usuario = r.id_usuario
    WHERE r.id_renta = ?
""";

    try (Connection conn = ConexionBD.conectar();
         PreparedStatement stmt = conn.prepareStatement(sql)) {

        stmt.setInt(1, idrenta);
        System.out.println("Ejecutando consulta con id_renta: " + idrenta);

        ResultSet rs = stmt.executeQuery();

        if (rs.next()) {
            correo = rs.getString("email");
            System.out.println("Correo obtenido: " + correo);
        } else {
            System.out.println("No se encontró ningún correo para el usuario ID: " );
        }

    } catch (Exception e) {
        e.printStackTrace();
    }

    return correo;
}



    public static void enviarComprobantePorCorreo(String destinatario, String archivoPDF) {
        final String remitente = "blockbustec@gmail.com";
        final String clave = "eexpznltkxfdmvtv"; // Usa clave de aplicación

        Properties props = new Properties();
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");

        Session session = Session.getInstance(props, new Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(remitente, clave);
            }
        });

        try {
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(remitente));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(destinatario));
            message.setSubject("🎬 Comprobante de Renta");

            BodyPart mensajeTexto = new MimeBodyPart();
            mensajeTexto.setText("Adjunto encontrarás el ticket de tu renta. ¡Gracias por usar nuestro servicio!");

            MimeBodyPart adjunto = new MimeBodyPart();
            adjunto.attachFile(new File(archivoPDF));

            Multipart multipart = new MimeMultipart();
            multipart.addBodyPart(mensajeTexto);
            multipart.addBodyPart(adjunto);

            message.setContent(multipart);

            Transport.send(message);
            System.out.println("Correo enviado correctamente.");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        btnEnviar = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        lblInfo = new javax.swing.JLabel();
        btnHistorial = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jSeparator1 = new javax.swing.JPopupMenu.Separator();
        jMenuItem2 = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Showcard Gothic", 0, 24)); // NOI18N
        jLabel1.setText("TICKET DE COMPRA");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 20, 240, 45));

        btnEnviar.setText("Enviar Comprobante");
        btnEnviar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEnviarActionPerformed(evt);
            }
        });
        getContentPane().add(btnEnviar, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 370, -1, -1));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblInfo.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jPanel1.add(lblInfo, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 80, 370, 240));

        btnHistorial.setText("Historial rentas");
        btnHistorial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHistorialActionPerformed(evt);
            }
        });
        jPanel1.add(btnHistorial, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 370, -1, -1));

        jPanel2.setBackground(new java.awt.Color(255, 102, 102));
        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 340, 420, 100));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 420, 440));

        jMenu1.setText("=");

        jMenuItem1.setText("Inicio");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem1);
        jMenu1.add(jSeparator1);

        jMenuItem2.setText("Cerrar ");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem2);

        jMenuBar1.add(jMenu1);

        setJMenuBar(jMenuBar1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        // TODO add your handling code here:
        MenuPrincipal menu = new MenuPrincipal();
    menu.setVisible(true);
    this.dispose();
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        // TODO add your handling code here:
        Login login = new Login();
    login.setVisible(true);
    this.dispose();
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void btnEnviarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEnviarActionPerformed
    int idrenta = this.idrenta;
    String correoUsuario = obtenerCorreoPorIdUsuario(idrenta);

    if (correoUsuario != "" && !correoUsuario.isEmpty()) {
        // Verificamos que los datos estén completos
        if (nombreUsuario != null && nombrePelicula != null && fechaRenta != null 
            && fechaDevolucion != null && precioRenta != null) {

            String archivoPDF = generarPDFTicket(nombreUsuario, nombrePelicula, fechaRenta, fechaDevolucion, precioRenta);

            if (archivoPDF != null) {
                enviarComprobantePorCorreo(correoUsuario, archivoPDF);
                JOptionPane.showMessageDialog(this, "Comprobante PDF enviado a: " + correoUsuario);
            } else {
                JOptionPane.showMessageDialog(this, "❌ No se pudo generar el archivo PDF.");
            }
        } else {
            JOptionPane.showMessageDialog(this, "⚠️ Faltan datos para generar el ticket.");
        }
    } else {
        JOptionPane.showMessageDialog(this, "⚠️ No se encontró el correo del usuario.");
    }

    }//GEN-LAST:event_btnEnviarActionPerformed

    private void btnHistorialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHistorialActionPerformed
        // TODO add your handling code here:
        
 new AdminCobro().setVisible(true);
this.setVisible(false);
    }//GEN-LAST:event_btnHistorialActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Ticket.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Ticket.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Ticket.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Ticket.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Ticket().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnEnviar;
    private javax.swing.JButton btnHistorial;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPopupMenu.Separator jSeparator1;
    private javax.swing.JLabel lblInfo;
    // End of variables declaration//GEN-END:variables
}
