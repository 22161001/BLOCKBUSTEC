package proyecto;

import bibliotecacontrasena.generarContrasena;
import conexion.ConexionBD;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.JOptionPane;


/**
 *
 * @author conan
 */
public class Registro extends javax.swing.JFrame {

    private boolean mostrarContraseña = false;
  
    
    /**
     * Creates new form Registro
     */
    public Registro() {
        initComponents();
        configurarLblMostrar1();
        configurarLblMostrar2();
        llenarroles();
        
    }
private void llenarroles(){
Listaroles listr = new Listaroles();
ArrayList<Rol> listaroles = listr.getRoles();
cbRoles.removeAllItems();
for(int i=0 ; i<listaroles.size();i++){
cbRoles.addItem(new Rol(listaroles.get(i).getIdRol(), listaroles.get(i).getNombreRol())) ;
}
}
    private void configurarLblMostrar1() {
        lblMostrar1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ojo-cruzado2.png")));
        lblMostrar1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        lblMostrar1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblMostrar1MouseClicked(evt);
            }
        });
    }

    private void lblMostrar1MouseClicked(java.awt.event.MouseEvent evt) {
        if (mostrarContraseña) {
            pswContra.setEchoChar('•');
            lblMostrar1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ojo-cruzado2.png")));
        } else {
            pswContra.setEchoChar((char) 0);
            lblMostrar1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ojo-abierto2.png")));
        }
        mostrarContraseña = !mostrarContraseña;
    }

    private void configurarLblMostrar2() {
        lblMostrar2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ojo-cruzado2.png")));
        lblMostrar2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        lblMostrar2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblMostrar2MouseClicked(evt);
            }
        });
    }

    private void lblMostrar2MouseClicked(java.awt.event.MouseEvent evt) {
        if (mostrarContraseña) {
            pswConfirmarContraseña.setEchoChar('•');
            lblMostrar2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ojo-cruzado2.png")));
        } else {
            pswConfirmarContraseña.setEchoChar((char) 0);
            lblMostrar2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ojo-abierto2.png")));
        }
        mostrarContraseña = !mostrarContraseña;
    }

private void registrarUsuarioEnBD() {
    
    limpiarMensajesError();

    String nombres = txtNombre.getText().trim();
    String apellidoPaterno = txtAPaterno.getText().trim();
    String apellidoMaterno = txtAMaterno.getText().trim();

    Date fecha = dtFechaNac.getDate();
    java.sql.Date fechaNacimiento = null;
    if (fecha != null) {
        fechaNacimiento = new java.sql.Date(fecha.getTime());
    }

    String genero = rbtnMasculino.isSelected() ? "Masculino" : (rbtnFemenino.isSelected() ? "Femenino" : "");
    String email = txtCorreroElect.getText().trim();
    String contrasena = new String(pswContra.getPassword()).trim();
    String confirmarContrasena = new String(pswConfirmarContraseña.getPassword()).trim();

    int rolIndex =0;
        rolIndex=    cbRoles.getItemAt(cbRoles.getSelectedIndex()).getIdRol();
    
    


    boolean valido = true;

    if (nombres.isEmpty()) {
        lblErrorNombre.setText("El nombre es obligatorio.");
        lblErrorNombre.setForeground(Color.RED);
        valido = false;
    }

    if (apellidoPaterno.isEmpty()) {
        lblErrorAP.setText("El apellido paterno es obligatorio.");
        lblErrorAP.setForeground(Color.RED);
        valido = false;
    }

    if (fechaNacimiento == null) {
        lblErrorFecha.setText("La fecha de nacimiento es obligatoria.");
        lblErrorFecha.setForeground(Color.RED);
        valido = false;
    }

    if (genero.isEmpty()) {
        lblErrorGenero.setText("Selecciona un género.");
        lblErrorGenero.setForeground(Color.RED);
        valido = false;
    }

    if (email.isEmpty()) {
        lblErrorCorreo.setText("El correo es obligatorio.");
        lblErrorCorreo.setForeground(Color.RED);
        valido = false;
    }

    if (contrasena.isEmpty()) {
        lblErrorContraseña.setText("La contraseña es obligatoria.");
        lblErrorContraseña.setForeground(Color.RED);
        valido = false;
    } else if (!contrasena.equals(confirmarContrasena)) {
        lblErrorContraseña.setText("Las contraseñas no coinciden.");
        lblErrorContraseña.setForeground(Color.RED);
        valido = false;
    }

    if (rolIndex==0) {
        lblErrorRol.setText("Selecciona un rol válido.");
        lblErrorRol.setForeground(Color.RED);
        valido = false;
    }

    // Verificar si el correo ya está registrado
    if (valido) {
        String correoSql = "SELECT COUNT(*) FROM usuarios WHERE email = ?";
        try (java.sql.Connection conn = ConexionBD.conectar();
             java.sql.PreparedStatement checkStmt = conn.prepareStatement(correoSql)) {

            checkStmt.setString(1, email);
            java.sql.ResultSet rs = checkStmt.executeQuery();
            if (rs.next() && rs.getInt(1) > 0) {
                lblErrorCorreo.setText("Este correo ya está registrado.");
                lblErrorCorreo.setForeground(Color.RED);
                return;
            }
        } catch (Exception ex) {
            lblErrorCorreo.setText("Error al verificar correo.");
            lblErrorCorreo.setForeground(Color.RED);
            ex.printStackTrace();
            return;
        }
    }

    if (!valido) {
        return;
    }

    String sql = "INSERT INTO usuarios (nombres, apellido_paterno, apellido_materno, fecha_nacimiento, genero, email, contrasena, id_rol) " +
                 "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

    try (java.sql.Connection conn = ConexionBD.conectar();
         java.sql.PreparedStatement stmt = conn.prepareStatement(sql)) {

        stmt.setString(1, nombres);
        stmt.setString(2, apellidoPaterno);
        stmt.setString(3, apellidoMaterno);
        stmt.setDate(4, fechaNacimiento);
        stmt.setString(5, genero);
        stmt.setString(6, email);
        stmt.setString(7, contrasena);
        stmt.setInt(8, rolIndex);

        int resultado = stmt.executeUpdate();
        if (resultado > 0) {
            JOptionPane.showMessageDialog(this, "Usuario registrado exitosamente.");
            limpiarCampos();
            AdminUsuarios usuarios = new AdminUsuarios();
            usuarios.setVisible(true);
            this.dispose();
        } else {
            lblErrorCorreo.setText("No se pudo registrar el usuario.");
            lblErrorCorreo.setForeground(Color.RED);
        }

    } catch (Exception ex) {
        lblErrorCorreo.setText("Error: " + ex.getMessage());
        lblErrorCorreo.setForeground(Color.RED);
        ex.printStackTrace();
    }
}


private void limpiarMensajesError() {
    lblErrorNombre.setText("");
    lblErrorAP.setText("");
    lblErrorAM.setText("");
    lblErrorFecha.setText("");
    lblErrorGenero.setText("");
    lblErrorCorreo.setText("");
    lblErrorContraseña.setText("");
    lblErrorRol.setText("");  
}

private void limpiarCampos() {
    txtNombre.setText("");
    txtAPaterno.setText("");
    txtAMaterno.setText("");
    dtFechaNac.setDate(null);
    genero.clearSelection();
    txtCorreroElect.setText("");
    pswContra.setText("");
    pswConfirmarContraseña.setText("");
    cbRoles.setSelectedIndex(0);  

    // Limpiar mensajes de error
    lblErrorContraseña.setText("");
    lblErrorCorreo.setText("");
    lblErrorGenero.setText("");
    lblErrorNombre.setText("");
    lblErrorAP.setText("");
    lblErrorAM.setText("");
    lblErrorFecha.setText("");
    lblErrorRol.setText("");
}




    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        genero = new javax.swing.ButtonGroup();
        jCalendar1 = new com.toedter.calendar.JCalendar();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        txtNombre = new javax.swing.JTextField();
        txtCorreroElect = new javax.swing.JTextField();
        pswContra = new javax.swing.JPasswordField();
        jLabel9 = new javax.swing.JLabel();
        pswConfirmarContraseña = new javax.swing.JPasswordField();
        lblErrorCorreo = new javax.swing.JLabel();
        lblMostrar2 = new javax.swing.JLabel();
        dtFechaNac = new com.toedter.calendar.JDateChooser();
        jPanel1 = new javax.swing.JPanel();
        txtAMaterno = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtAPaterno = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        lblErrorAP = new javax.swing.JLabel();
        lblErrorAM = new javax.swing.JLabel();
        rbtnMasculino = new javax.swing.JRadioButton();
        rbtnFemenino = new javax.swing.JRadioButton();
        jLabel8 = new javax.swing.JLabel();
        lblErrorGenero = new javax.swing.JLabel();
        cbRoles = new javax.swing.JComboBox<>();
        jLabel10 = new javax.swing.JLabel();
        lblErrorRol = new javax.swing.JLabel();
        btnCancelar = new javax.swing.JButton();
        lblMostrar1 = new javax.swing.JLabel();
        btnGeneraSegura = new javax.swing.JButton();
        lblErrorNombre = new javax.swing.JLabel();
        lblErrorFecha = new javax.swing.JLabel();
        lblErrorContraseña = new javax.swing.JLabel();
        btnAceptar1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Showcard Gothic", 3, 24)); // NOI18N
        jLabel1.setText("REGISTRO USUARIO");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 20, 280, 30));

        jLabel2.setFont(new java.awt.Font("FZYaoTi", 0, 14)); // NOI18N
        jLabel2.setText("Nombre(s):");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 60, -1, -1));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel5.setText("Correo electronico:");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 240, -1, -1));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel6.setText("Fecha de Nacimiento:");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 180, -1, -1));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel7.setText("Contraseña:");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 300, -1, -1));

        txtNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNombreActionPerformed(evt);
            }
        });
        getContentPane().add(txtNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 60, 154, -1));

        txtCorreroElect.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCorreroElectActionPerformed(evt);
            }
        });
        getContentPane().add(txtCorreroElect, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 240, 270, -1));

        pswContra.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pswContraActionPerformed(evt);
            }
        });
        pswContra.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                pswContraKeyReleased(evt);
            }
        });
        getContentPane().add(pswContra, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 300, 180, -1));

        jLabel9.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel9.setText("Confirmar contraseña:");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 360, -1, -1));

        pswConfirmarContraseña.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                pswConfirmarContraseñaKeyReleased(evt);
            }
        });
        getContentPane().add(pswConfirmarContraseña, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 360, 180, -1));
        getContentPane().add(lblErrorCorreo, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 270, 270, 20));
        getContentPane().add(lblMostrar2, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 350, 30, 30));
        getContentPane().add(dtFechaNac, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 180, 180, -1));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtAMaterno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtAMaternoActionPerformed(evt);
            }
        });
        jPanel1.add(txtAMaterno, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 120, 154, -1));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel4.setText("Apellido Materno:");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 120, -1, -1));

        txtAPaterno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtAPaternoActionPerformed(evt);
            }
        });
        jPanel1.add(txtAPaterno, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 60, 154, -1));

        jLabel3.setFont(new java.awt.Font("FZYaoTi", 0, 14)); // NOI18N
        jLabel3.setText("Apellido Paterno:");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 60, -1, -1));
        jPanel1.add(lblErrorAP, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 90, 190, 20));
        jPanel1.add(lblErrorAM, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 150, 150, 20));

        genero.add(rbtnMasculino);
        rbtnMasculino.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        rbtnMasculino.setText("Masculino");
        rbtnMasculino.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtnMasculinoActionPerformed(evt);
            }
        });
        jPanel1.add(rbtnMasculino, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 110, -1, -1));

        genero.add(rbtnFemenino);
        rbtnFemenino.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        rbtnFemenino.setText("Femenino");
        rbtnFemenino.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtnFemeninoActionPerformed(evt);
            }
        });
        jPanel1.add(rbtnFemenino, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 130, -1, -1));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel8.setText("Genero: ");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 130, -1, 20));
        jPanel1.add(lblErrorGenero, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 150, 220, 20));

        cbRoles.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbRolesActionPerformed(evt);
            }
        });
        jPanel1.add(cbRoles, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 190, -1, -1));

        jLabel10.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel10.setText("Rol de Usuario:");
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 190, -1, -1));
        jPanel1.add(lblErrorRol, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 220, 160, 20));

        btnCancelar.setText("Cancelar");
        btnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarActionPerformed(evt);
            }
        });
        jPanel1.add(btnCancelar, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 440, -1, -1));
        jPanel1.add(lblMostrar1, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 290, 30, 30));

        btnGeneraSegura.setText("Contraseña Sugerida");
        btnGeneraSegura.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGeneraSeguraActionPerformed(evt);
            }
        });
        jPanel1.add(btnGeneraSegura, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 320, -1, -1));
        jPanel1.add(lblErrorNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 90, 160, 20));
        jPanel1.add(lblErrorFecha, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 210, 240, 20));
        jPanel1.add(lblErrorContraseña, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 330, 230, 20));

        btnAceptar1.setText("Aceptar");
        btnAceptar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAceptar1ActionPerformed(evt);
            }
        });
        jPanel1.add(btnAceptar1, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 410, 119, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 640, 480));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void rbtnFemeninoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtnFemeninoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rbtnFemeninoActionPerformed

    private void txtNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNombreActionPerformed

    private void txtAPaternoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtAPaternoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtAPaternoActionPerformed

    private void txtAMaternoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtAMaternoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtAMaternoActionPerformed

    private void rbtnMasculinoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtnMasculinoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rbtnMasculinoActionPerformed

    private void txtCorreroElectActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCorreroElectActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCorreroElectActionPerformed

    private void btnAceptar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAceptar1ActionPerformed

        registrarUsuarioEnBD();
    }//GEN-LAST:event_btnAceptar1ActionPerformed

    private void btnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarActionPerformed
        // TODO add your handling code here:
        AdminUsuarios usuarios = new AdminUsuarios();
    usuarios.setVisible(true);
    this.dispose();
    }//GEN-LAST:event_btnCancelarActionPerformed

    private void pswContraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pswContraActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_pswContraActionPerformed

    private void btnGeneraSeguraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGeneraSeguraActionPerformed
        // TODO add your handling code here:
        String password = generarContrasena.generaPassword(8);
        while (!generarContrasena.cumpleRequisitos(password)) {
            password = generarContrasena.generaPassword(8);
        }
        pswContra.setText(password);
        pswConfirmarContraseña.setText(password);

        generarContrasena.resultadoValidacion resultado = generarContrasena.seguridadContraseña(password);
        lblErrorContraseña.setText(resultado.getMensaje());
        lblErrorContraseña.setForeground((resultado.getColor()));
    }//GEN-LAST:event_btnGeneraSeguraActionPerformed

    private void pswContraKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_pswContraKeyReleased
        // TODO add your handling code here:
    String password = new String(pswContra.getPassword());
    String passwordLimpia = generarContrasena.limpiarEspacios(password);

    
    pswContra.setText(passwordLimpia);

    generarContrasena.resultadoValidacion resultado = generarContrasena.seguridadContraseña(passwordLimpia);
    lblErrorContraseña.setText(resultado.getMensaje());
    lblErrorContraseña.setForeground(resultado.getColor()); 
    }//GEN-LAST:event_pswContraKeyReleased

    private void pswConfirmarContraseñaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_pswConfirmarContraseñaKeyReleased
        // TODO add your handling code here:
    String password = new String(pswConfirmarContraseña.getPassword());
    String passwordLimpia = generarContrasena.limpiarEspacios(password);

    
    pswConfirmarContraseña.setText(passwordLimpia);

    
    generarContrasena.resultadoValidacion resultado = generarContrasena.seguridadContraseña(passwordLimpia);
    lblErrorContraseña.setText(resultado.getMensaje());
    lblErrorContraseña.setForeground(resultado.getColor()); 
    }//GEN-LAST:event_pswConfirmarContraseñaKeyReleased

    private void cbRolesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbRolesActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_cbRolesActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Registro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Registro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Registro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Registro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Registro().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAceptar1;
    private javax.swing.JButton btnCancelar;
    private javax.swing.JButton btnGeneraSegura;
    private volatile javax.swing.JComboBox<Rol> cbRoles;
    private com.toedter.calendar.JDateChooser dtFechaNac;
    private javax.swing.ButtonGroup genero;
    private com.toedter.calendar.JCalendar jCalendar1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lblErrorAM;
    private javax.swing.JLabel lblErrorAP;
    private javax.swing.JLabel lblErrorContraseña;
    private javax.swing.JLabel lblErrorCorreo;
    private javax.swing.JLabel lblErrorFecha;
    private javax.swing.JLabel lblErrorGenero;
    private javax.swing.JLabel lblErrorNombre;
    private javax.swing.JLabel lblErrorRol;
    private javax.swing.JLabel lblMostrar1;
    private javax.swing.JLabel lblMostrar2;
    private javax.swing.JPasswordField pswConfirmarContraseña;
    private javax.swing.JPasswordField pswContra;
    private javax.swing.JRadioButton rbtnFemenino;
    private javax.swing.JRadioButton rbtnMasculino;
    private javax.swing.JTextField txtAMaterno;
    private javax.swing.JTextField txtAPaterno;
    private javax.swing.JTextField txtCorreroElect;
    private javax.swing.JTextField txtNombre;
    // End of variables declaration//GEN-END:variables

  }
