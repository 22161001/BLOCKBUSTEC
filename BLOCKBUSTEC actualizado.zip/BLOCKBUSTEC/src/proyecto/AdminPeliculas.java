
package proyecto;

import javax.swing.table.DefaultTableModel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

/**
 *
 * @author conan
 */
public class AdminPeliculas extends javax.swing.JFrame {

    /**
     * Creates new form AdminPeliculas
     */
    public AdminPeliculas() {
        initComponents();
        cargarPeliculas();
        configurarBarraBusqueda();
    }
        private void configurarBarraBusqueda() {
        String[] campos = {"titulo"};

       
        barraBusquedaPop1.cargarDesdeBaseDeDatos(
            "jdbc:postgresql://localhost:5433/blockbustec",
            "postgres",
            "conant14",
            "peliculas",
            campos
        );

           barraBusquedaPop1.setOnItemSelected(textoSeleccionado -> {
        if (textoSeleccionado == null || textoSeleccionado.trim().isEmpty()) {
            cargarPeliculas(); // Recarga todas las películas
        } else {
            cargarPeliculasPorTitulo(textoSeleccionado);
        }
    });

 
    JTextField campo = barraBusquedaPop1.getCampoBusqueda();

    // Agregar listener para detectar cuando el campo queda vacío
    campo.getDocument().addDocumentListener(new DocumentListener() {
        private void verificarCampoVacio() {
            String texto = campo.getText().trim();
            if (texto.isEmpty()) {
                cargarPeliculas(); 
            }
        }

        @Override
        public void insertUpdate(DocumentEvent e) {
            verificarCampoVacio();
        }

        @Override
        public void removeUpdate(DocumentEvent e) {
            verificarCampoVacio();
        }

        @Override
        public void changedUpdate(DocumentEvent e) {
            verificarCampoVacio();
        }
    });
}

private void cargarPeliculasPorTitulo(String textoBusqueda) {
    DefaultTableModel modelo = new DefaultTableModel();
    modelo.addColumn("ID");
    modelo.addColumn("Título");
    modelo.addColumn("Descripción");
    modelo.addColumn("Género");
    modelo.addColumn("Director");
    modelo.addColumn("Año");
    modelo.addColumn("Duración");
    modelo.addColumn("Imagen");
    modelo.addColumn("Disponible");

    String sql = """
        SELECT p.id_pelicula,
               p.titulo,
               p.descripcion,
               g.nombre_genero AS genero,
               p.director,
               p.anio,
               p.duracion,
               p.imagen_url,
               p.stock
        FROM peliculas p
        JOIN genero g ON p.id_genero = g.id_genero
        WHERE p.titulo ILIKE ?
        ORDER BY p.titulo
    """;

    try (java.sql.Connection conn = conexion.ConexionBD.conectar();
         java.sql.PreparedStatement stmt = conn.prepareStatement(sql)) {

        String filtro = "%" + textoBusqueda.trim() + "%";
        stmt.setString(1, filtro);

        try (java.sql.ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Object[] fila = {
                    rs.getInt("id_pelicula"),
                    rs.getString("titulo"),
                    rs.getString("descripcion"),
                    rs.getString("genero"),
                    rs.getString("director"),
                    rs.getInt("anio"),
                    rs.getString("duracion"),
                    rs.getString("imagen_url"),
                    rs.getInt("stock")
                };
                modelo.addRow(fila);
            }
        }

        tbPelicula.setModel(modelo);

        if (tbPelicula.getColumnCount() > 0) {
            tbPelicula.getColumnModel().getColumn(0).setPreferredWidth(40);
            tbPelicula.getColumnModel().getColumn(1).setPreferredWidth(150);
            tbPelicula.getColumnModel().getColumn(2).setPreferredWidth(250);
            tbPelicula.getColumnModel().getColumn(3).setPreferredWidth(100);
            tbPelicula.getColumnModel().getColumn(4).setPreferredWidth(120);
            tbPelicula.getColumnModel().getColumn(5).setPreferredWidth(60);
            tbPelicula.getColumnModel().getColumn(6).setPreferredWidth(80);
            tbPelicula.getColumnModel().getColumn(7).setPreferredWidth(200);
            tbPelicula.getColumnModel().getColumn(8).setPreferredWidth(80);
        }

    } catch (Exception e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Error al buscar películas.", "Error", JOptionPane.ERROR_MESSAGE);
    }
}



     private void cargarPeliculas() {
    DefaultTableModel modelo = new DefaultTableModel();
    modelo.addColumn("ID");
    modelo.addColumn("Título");
    modelo.addColumn("Descripción");
    modelo.addColumn("Género");
    modelo.addColumn("Director");
    modelo.addColumn("Año");
    modelo.addColumn("Duración");
    modelo.addColumn("Imagen");
    modelo.addColumn("Disponible"); 

  String sql = """
    SELECT p.id_pelicula,
           p.titulo,
           p.descripcion,
           g.nombre_genero AS genero, -- Asegúrate de que esta línea esté presente
           p.director,
           p.anio,
           p.duracion,
           p.imagen_url,
           p.stock
    FROM peliculas p
    JOIN genero g ON p.id_genero = g.id_genero
    ORDER BY p.titulo
""";
    try (java.sql.Connection conn = conexion.ConexionBD.conectar();
         java.sql.PreparedStatement stmt = conn.prepareStatement(sql);
         java.sql.ResultSet rs = stmt.executeQuery()) {

        while (rs.next()) {
            Object[] fila = {
                rs.getInt("id_pelicula"),
                rs.getString("titulo"),
                rs.getString("descripcion"),
               rs.getString("genero"),
                rs.getString("director"),
                rs.getInt("anio"),
                rs.getString("duracion"),
                rs.getString("imagen_url"),
                rs.getInt("stock") // directamente entero
            };
            modelo.addRow(fila);
        }

        tbPelicula.setModel(modelo);
        tbPelicula.getColumnModel().getColumn(0).setPreferredWidth(40);
        tbPelicula.getColumnModel().getColumn(1).setPreferredWidth(150);
        tbPelicula.getColumnModel().getColumn(2).setPreferredWidth(250);
        tbPelicula.getColumnModel().getColumn(3).setPreferredWidth(100);
        tbPelicula.getColumnModel().getColumn(4).setPreferredWidth(120);
        tbPelicula.getColumnModel().getColumn(5).setPreferredWidth(60);
        tbPelicula.getColumnModel().getColumn(6).setPreferredWidth(80);
        tbPelicula.getColumnModel().getColumn(7).setPreferredWidth(200);
        tbPelicula.getColumnModel().getColumn(8).setPreferredWidth(80);

    } catch (Exception e) {
        e.printStackTrace();
    }
}


public void actualizarTablaPeliculas() {
    cargarPeliculas();
}
    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tbPelicula = new javax.swing.JTable();
        btnAgregar = new javax.swing.JButton();
        btnVolver = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        btnEliminar = new javax.swing.JButton();
        btnEditar = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        barraBusquedaPop1 = new barrabusquedapop.barraBusquedaPop();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tbPelicula.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tbPelicula);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 100, 840, 490));

        btnAgregar.setText("Agregar");
        btnAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarActionPerformed(evt);
            }
        });
        getContentPane().add(btnAgregar, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 90, -1, -1));

        btnVolver.setText("Volver");
        btnVolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVolverActionPerformed(evt);
            }
        });
        getContentPane().add(btnVolver, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 530, -1, -1));

        jPanel1.setBackground(new java.awt.Color(255, 102, 102));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });
        jPanel1.add(btnEliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 170, -1, -1));

        btnEditar.setText("Editar");
        btnEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarActionPerformed(evt);
            }
        });
        jPanel1.add(btnEditar, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 130, -1, -1));

        jLabel1.setFont(new java.awt.Font("Showcard Gothic", 0, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("HISTORIAL DE PELICULAS");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 20, 478, 42));
        jPanel1.add(barraBusquedaPop1, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 60, -1, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 990, 620));

        jMenu1.setText("=");
        jMenuBar1.add(jMenu1);

        setJMenuBar(jMenuBar1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnVolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVolverActionPerformed
        // TODO add your handling code here:
        AdminPanel AdminPanel = new AdminPanel();
    AdminPanel.setVisible(true);
    this.dispose();
    }//GEN-LAST:event_btnVolverActionPerformed

    private void btnAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarActionPerformed
        // TODO add your handling code here:
        new PanelPeliculas(this).setVisible(true); 
    }//GEN-LAST:event_btnAgregarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
         int fila = tbPelicula.getSelectedRow();
    if (fila == -1) {
        JOptionPane.showMessageDialog(this, "Selecciona una película para eliminar.");
        return;
    }

    int id = (int) tbPelicula.getValueAt(fila, 0);

   
    int opcion = JOptionPane.showOptionDialog(this,
        "¿Seguro que quieres eliminar esta película?",
        "Confirmar eliminación",
        JOptionPane.YES_NO_OPTION,
        JOptionPane.QUESTION_MESSAGE,
        null,
        new Object[]{"Sí", "No"},
        "No");

    if (opcion == JOptionPane.YES_OPTION) {
        String sql = "DELETE FROM peliculas WHERE id_pelicula = ?";
        try (java.sql.Connection conn = conexion.ConexionBD.conectar();
             java.sql.PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Película eliminada.");
            cargarPeliculas();
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al eliminar la película.");
        }
    }
    
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarActionPerformed
        // TODO add your handling code here:
         int fila = tbPelicula.getSelectedRow();
    if (fila == -1) {
        JOptionPane.showMessageDialog(this, "Selecciona una película.");
        return;
    }

    int id = (int) tbPelicula.getValueAt(fila, 0);
    String titulo = tbPelicula.getValueAt(fila, 1).toString();
    String descripcion = tbPelicula.getValueAt(fila, 2).toString();
    String genero = tbPelicula.getValueAt(fila, 3).toString();
    String director = tbPelicula.getValueAt(fila, 4).toString();
    int anio;

 
        anio = Integer.parseInt(tbPelicula.getValueAt(fila, 5).toString());

        
            int duracion=Integer.parseInt((String) tbPelicula.getValueAt(fila, 6));
        



    String imagenUrl = tbPelicula.getValueAt(fila, 7).toString();
    int disponible;
try {
    disponible = Integer.parseInt(tbPelicula.getValueAt(fila, 8).toString());
} catch (NumberFormatException e) {
    JOptionPane.showMessageDialog(this, "Cantidad disponible inválida.");
    return;
}
    PanelPeliculas ventanaEditar = new PanelPeliculas(this);
    ventanaEditar.cargarDatosPelicula(id, titulo, descripcion, genero, director, anio, duracion, imagenUrl, disponible);
    ventanaEditar.setVisible(true);
    

        
    }//GEN-LAST:event_btnEditarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AdminPeliculas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AdminPeliculas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AdminPeliculas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AdminPeliculas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AdminPeliculas().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private barrabusquedapop.barraBusquedaPop barraBusquedaPop1;
    private javax.swing.JButton btnAgregar;
    private javax.swing.JButton btnEditar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnVolver;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tbPelicula;
    // End of variables declaration//GEN-END:variables
}
