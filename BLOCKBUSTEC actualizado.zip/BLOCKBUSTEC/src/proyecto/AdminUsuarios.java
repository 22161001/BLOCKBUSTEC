
package proyecto;

import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author conan
 */
public class AdminUsuarios extends javax.swing.JFrame {


    /**
     * Creates new form AdminPanel
     */
     public AdminUsuarios() {
        initComponents();
        cargarUsuarios();
        configurarBarraBusqueda();
        
      
    }
  private void configurarBarraBusqueda() {
    String[] campos = {"nombres", "apellido_paterno", "apellido_materno"};

 
    barraBusquedaPop1.cargarDesdeBaseDeDatos(
        "jdbc:postgresql://localhost:5433/blockbustec",
        "postgres",
        "conant14",
        "usuarios",
        campos
    );

    
    barraBusquedaPop1.setOnItemSelected(textoSeleccionado -> {
        if (textoSeleccionado == null || textoSeleccionado.trim().isEmpty()) {
            cargarUsuarios(); 
        } else {
            cargarUsuariosPorNombreApellido(textoSeleccionado);
        }
    });

    
    JTextField campo = barraBusquedaPop1.getCampoBusqueda();

    campo.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
        private void verificarCampoVacio() {
            String texto = campo.getText().trim();
            if (texto.isEmpty()) {
                cargarUsuarios(); 
            }
        }

        @Override
        public void insertUpdate(javax.swing.event.DocumentEvent e) {
            verificarCampoVacio();
        }

        @Override
        public void removeUpdate(javax.swing.event.DocumentEvent e) {
            verificarCampoVacio();
        }

        @Override
        public void changedUpdate(javax.swing.event.DocumentEvent e) {
            verificarCampoVacio();
        }
    });
}


    private void cargarUsuariosPorNombreApellido(String texto) {
    DefaultTableModel modelo = new DefaultTableModel();
    modelo.addColumn("ID");
    modelo.addColumn("Nombre completo");
    modelo.addColumn("Correo");
    modelo.addColumn("Rol");

   
    Integer idBuscado = null;
    try {
        idBuscado = Integer.parseInt(texto.trim());
    } catch (NumberFormatException e) {
       
    }

    String[] palabras = texto.trim().split("\\s+");

    StringBuilder sql = new StringBuilder();
    sql.append("SELECT u.id_usuario, u.nombres, u.apellido_paterno, u.apellido_materno, u.email, r.nombre_rol ");
    sql.append("FROM usuarios u JOIN roles r ON u.id_rol = r.id_rol ");
    sql.append("WHERE ");

    if (idBuscado != null) {
        
        sql.append("u.id_usuario = ? OR ");
    }

   
    for (int i = 0; i < palabras.length; i++) {
        if (i > 0) sql.append(" AND ");
        sql.append("(");
        sql.append("u.nombres ILIKE ? OR ");
        sql.append("u.apellido_paterno ILIKE ? OR ");
        sql.append("u.apellido_materno ILIKE ?");
        sql.append(")");
    }

    sql.append(" ORDER BY u.apellido_paterno, u.nombres");

    try (java.sql.Connection conn = conexion.ConexionBD.conectar();
         java.sql.PreparedStatement stmt = conn.prepareStatement(sql.toString())) {

        int paramIndex = 1;

        if (idBuscado != null) {
            stmt.setInt(paramIndex++, idBuscado);
        }

        for (String palabra : palabras) {
            String filtro = "%" + palabra + "%";
            stmt.setString(paramIndex++, filtro);
            stmt.setString(paramIndex++, filtro);
            stmt.setString(paramIndex++, filtro);
        }

        try (java.sql.ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                String nombreCompleto = rs.getString("nombres") + " " +
                                        rs.getString("apellido_paterno") + " " +
                                        rs.getString("apellido_materno");

                Object[] fila = {
                    rs.getInt("id_usuario"),
                    nombreCompleto,
                    rs.getString("email"),
                    rs.getString("nombre_rol")
                };
                modelo.addRow(fila);
            }
        }

        tbUsuario.setModel(modelo);
        tbUsuario.getColumnModel().getColumn(0).setPreferredWidth(30);
        tbUsuario.getColumnModel().getColumn(1).setPreferredWidth(200);
        tbUsuario.getColumnModel().getColumn(2).setPreferredWidth(200);
        tbUsuario.getColumnModel().getColumn(3).setPreferredWidth(100);

    } catch (Exception e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Error al buscar usuarios.", "Error", JOptionPane.ERROR_MESSAGE);
    }
}

    private void cargarUsuarios() {
        DefaultTableModel modelo = new DefaultTableModel();
        modelo.addColumn("ID");
        modelo.addColumn("Nombre completo");
        modelo.addColumn("Correo");
        modelo.addColumn("Rol");

        String sql = """
        SELECT u.id_usuario,
               u.nombres,
               u.apellido_paterno,
               u.apellido_materno,
               u.email,
               r.nombre_rol
        FROM usuarios u
        JOIN roles r ON u.id_rol = r.id_rol
        ORDER BY u.apellido_paterno, u.nombres
        """;

        try (java.sql.Connection conn = conexion.ConexionBD.conectar();
             java.sql.PreparedStatement stmt = conn.prepareStatement(sql);
             java.sql.ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                String nombreCompleto = rs.getString("nombres") + " " +
                                        rs.getString("apellido_paterno") + " " +
                                        rs.getString("apellido_materno");

                Object[] fila = {
                    rs.getInt("id_usuario"),
                    nombreCompleto,
                    rs.getString("email"),
                    rs.getString("nombre_rol")
                };
                modelo.addRow(fila);
            }

            tbUsuario.setModel(modelo);
            tbUsuario.getColumnModel().getColumn(0).setPreferredWidth(30);
            tbUsuario.getColumnModel().getColumn(1).setPreferredWidth(200);
            tbUsuario.getColumnModel().getColumn(2).setPreferredWidth(200);
            tbUsuario.getColumnModel().getColumn(3).setPreferredWidth(100);

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al cargar usuarios.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }



    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenuItem1 = new javax.swing.JMenuItem();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tbUsuario = new javax.swing.JTable();
        btnAgregarU = new javax.swing.JButton();
        btnEliminarUser = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        barraBusquedaPop1 = new barrabusquedapop.barraBusquedaPop();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem2 = new javax.swing.JMenuItem();

        jMenuItem1.setText("jMenuItem1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(255, 102, 102));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tbUsuario.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane2.setViewportView(tbUsuario);

        jPanel2.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 90, 850, 480));

        btnAgregarU.setText("Agregar");
        btnAgregarU.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarUActionPerformed(evt);
            }
        });
        jPanel2.add(btnAgregarU, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 80, -1, -1));

        btnEliminarUser.setText("Eliminar");
        btnEliminarUser.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarUserActionPerformed(evt);
            }
        });
        jPanel2.add(btnEliminarUser, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 130, -1, -1));

        jButton1.setText("Volver");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 540, -1, -1));

        jLabel1.setFont(new java.awt.Font("Showcard Gothic", 0, 28)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("ADMINISTRACION DE  usuarios");
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 10, -1, 45));
        jPanel2.add(barraBusquedaPop1, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 50, -1, -1));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 990, 610));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1000, 610));

        jMenu1.setText("=");

        jMenuItem2.setText("Cerrar Sesion");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem2);

        jMenuBar1.add(jMenu1);

        setJMenuBar(jMenuBar1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        // TODO add your handling code here:
        Login login = new Login();
    login.setVisible(true);
    this.dispose();
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void btnEliminarUserActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarUserActionPerformed
           int fila = tbUsuario.getSelectedRow();
    if (fila == -1) {
        JOptionPane.showMessageDialog(this, "Selecciona un usuario para eliminar.");
        return;
    }

    int id = (int) tbUsuario.getValueAt(fila, 0);

   
    int opcion = JOptionPane.showOptionDialog(this,
        "¿Seguro que quieres eliminar este usuario?",
        "Confirmar eliminación",
        JOptionPane.YES_NO_OPTION,
        JOptionPane.QUESTION_MESSAGE,
        null,
        new Object[]{"Sí", "No"},
        "No");

    if (opcion == JOptionPane.YES_OPTION) {
        String sql = "DELETE FROM usuarios WHERE id_usuario = ?";
        try (java.sql.Connection conn = conexion.ConexionBD.conectar();
             java.sql.PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Usuario eliminado.");
            cargarUsuarios();

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al eliminar usuario.");
        }
    }
    }//GEN-LAST:event_btnEliminarUserActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        AdminPanel AdminPanel = new AdminPanel();
    AdminPanel.setVisible(true);
    this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void btnAgregarUActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarUActionPerformed
        // TODO add your handling code here:
        new Registro().setVisible(true); 
    this.dispose();
    }//GEN-LAST:event_btnAgregarUActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AdminUsuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AdminUsuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AdminUsuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AdminUsuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AdminUsuarios().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private barrabusquedapop.barraBusquedaPop barraBusquedaPop1;
    private javax.swing.JButton btnAgregarU;
    private javax.swing.JButton btnEliminarUser;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable tbUsuario;
    // End of variables declaration//GEN-END:variables
}
