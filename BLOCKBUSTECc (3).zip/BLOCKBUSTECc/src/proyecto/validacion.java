/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto;

import java.util.regex.Pattern;


/**
 *
 * @author conan
 */
public class validacion {
    
    
    public static boolean validarUsuario(String usuario) {
        usuario = usuario.toLowerCase();
        String correo = "^[a-zA-Z0-9._%+-]+@(gmail.com|outlook.com|yahoo.com|itoaxaca.com|hotmail.com)$";
        return Pattern.matches(correo, usuario);
    }

    public static boolean validarContraseña(String contraseña) {
        return contraseña.length() == 8;
    }
    
    public static boolean validarLetras(String texto) {
        String patron = "^[a-zA-ZáéíóúÁÉÍÓÚñÑ ]+$"; 
        return Pattern.matches(patron, texto);
    }
    
    public static boolean validarNoVacio(String texto) {
        return texto.trim().length() > 0;
     }
     
   

}
  

