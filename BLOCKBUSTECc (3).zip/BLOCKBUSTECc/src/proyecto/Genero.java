/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto;

/**
 *
 * @author emili
 */
public class Genero {
     private int idGenero;
    private String nombreGenero;

    // Primer constructor: Sin parámetros (constructor por defecto)
    public Genero() {
        
    }

    // Segundo constructor: Con parámetros (para inicializar al crear un objeto)
    public Genero(int idGenero, String nombreGenero) {
        this.idGenero = idGenero;
        this.nombreGenero = nombreGenero;
    }

    // Método Getter para idGenero
    public int getIdGenero() {
        return idGenero;
    }

    // Método Setter para idGenero
    public void setIdGenero(int idGenero) {
        this.idGenero = idGenero;
    }

    // Método Getter para nombreGenero
    public String getNombreGenero() {
        return nombreGenero;
    }

    // Método Setter para nombreGenero
    public void setNombreGenero(String nombreGenero) {
        this.nombreGenero = nombreGenero;
    }

   
    @Override
    public String toString() {
        return nombreGenero;
    }
}
