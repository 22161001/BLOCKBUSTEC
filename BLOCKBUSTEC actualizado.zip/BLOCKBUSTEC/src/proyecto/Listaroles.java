/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto;


import java.util.ArrayList;
import conexion.ConexionBD;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;


public class Listaroles {
    


  

    public  ArrayList<Rol> getRoles() { 
        Connection con = ConexionBD.conectar();
        Statement stmt;
        ResultSet rs;
        ArrayList<Rol> listaroles= new ArrayList<>();
        try {
            stmt = con.createStatement();
           rs = stmt.executeQuery("select*from roles");
            while (rs.next()) {
     Rol rols = new Rol();
     rols.setIdRol(rs.getInt("id_rol"));
     rols.setNombreRol(rs.getString("nombre_rol"));
listaroles.add(rols);
                
            }
        } catch (SQLException ex) {
            Logger.getLogger(Listaroles.class.getName()).log(Level.SEVERE, null, ex);
        }
        return listaroles;
    }
     public  ArrayList<Genero> getPeliculas() { 
        Connection con = ConexionBD.conectar();
        Statement stmt;
        ResultSet rs;
        ArrayList<Genero> listaroles= new ArrayList<>();
        try {
            stmt = con.createStatement();
           rs = stmt.executeQuery("select*from genero");
            while (rs.next()) {
     Genero rols = new Genero();
     rols.setIdGenero(rs.getInt("id_genero"));
     rols.setNombreGenero(rs.getString("nombre_genero"));
listaroles.add(rols);
                
            }
        } catch (SQLException ex) {
            Logger.getLogger(Listaroles.class.getName()).log(Level.SEVERE, null, ex);
        }
        return listaroles;
    }


}
